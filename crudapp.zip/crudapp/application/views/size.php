<?php include('header.php') ?>

<div class="container" style="margin-top: 50px;">
    

    <?php if($error= $this->session->flashdata('success')): ?>

    <div class="row">
      <div class="col-lg-6">
        <div class="alert alert-success"><?php echo $error ?></div>
      </div>
    </div>


<?php endif;?>

<?php if($error= $this->session->flashdata('msg')): ?>

    <div class="row">
      <div class="col-lg-6">
        <div class="alert alert-danger"><?php echo $error ?></div>
      </div>
    </div>


<?php endif;?>






 <a class="btn btn-primary " href="<?php echo base_url('home/addsize');?>" id="toggleNavPosition"><i class="fa fa-plus"></i> Add Size</a>



<hr/>




<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>SN</th>
                <th>Category</th>
                <th>Edit</th>
                <th>Delete</th>
                
            </tr>
        </thead>
        <tbody>
              <?php if (count($size)): ?>
          <?php foreach ($size as $size): ?>
          <tr>
            
            <td><?php echo $size->sid;  ?></td>
            
            <td><?php echo $size->size;  ?></td>
            

           
            <td><?=  anchor("home/editsize/{$size->sid}",'Edit',['class'=>'btn btn-info']);  ?></td>
            <td>
        <?=
        form_open('home/deletesize'),
        form_hidden('sid',$size->sid),
        form_submit(['name'=>'submit','value'=>'Delete','class'=>'btn btn-danger']),
        form_close();



        ?>
      </td>
          </tr>
        
    <?php endforeach; ?>
    <?php else:?>
      <tr>
        <td colspan="4">No Data Abalable</td>
      </tr>
  <?php endif; ?>
            
        </tbody>
        <tfoot>
            <tr>
                <th>SN</th>
                <th>Size</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </tfoot>
    </table>







</div>




<?php include('footer.php') ?>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>