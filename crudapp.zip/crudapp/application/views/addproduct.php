<?php include('header.php') ?>


<div class="container" style="margin-top: 50px; border: ">

<?php echo form_open('Home/prosubmit');?>


<div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Product Name</label>
    <?php echo form_input(['class'=>'form-control','placeholder'=>'Enter Product Name','name'=>'pname','value'=>set_value('pname')]); ?>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('pname'); ?>
    </div>
  </div>

  <div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Category</label>
   
    <select class="form-control" name="catname">
      <option value="">Select</option>
       <?php if (count($cat)): ?>
          <?php foreach ($cat as $cat): ?>

              <option value=<?php echo $cat->catid ?>><?php echo $cat->catname ?></option>
             

            <?php endforeach; ?>
    <?php endif;?>
    </select>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('catname'); ?>
    </div> 
  </div>


  <div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Price</label>
    <?php echo form_input(['class'=>'form-control','placeholder'=>'Enter Category','name'=>'pprice','value'=>set_value('pprice')]); ?>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('pprice'); ?>
    </div>
  </div>

  <div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Size</label>
   
    <select class="form-control" name="size">
      <option value="">Select</option>
       <?php if (count($siz)): ?>
          <?php foreach ($siz as $siz): ?>
              <option value=<?php echo $siz->sid ?>><?php echo $siz->size ?></option>
              

            <?php endforeach; ?>
    <?php endif;?>
    </select>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('size'); ?>
    </div> 
  </div>



<div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Stock</label>
    <?php echo form_input(['class'=>'form-control','placeholder'=>'Enter Stock','name'=>'pstock','value'=>set_value('pstock')]); ?>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('pstock'); ?>
    </div>
  </div>


  <div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Description</label>
    <?php echo form_textarea(['class'=>'form-control','placeholder'=>'Enter Description','name'=>'pdescription','value'=>set_value('pdescription')]); ?>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('pdescription'); ?>
    </div>
  </div>


  <?php echo form_submit(['class'=>'btn btn-primary','type'=>'submit','value'=>'Submit']); ?>
  <?php echo form_reset(['class'=>'btn btn-success','type'=>'reset','value'=>'Reset']); ?>
  
</div>
  <?php include('footer.php') ?>


