<?php include('header.php') ?>


<div class="container" style="margin-top: 50px; border: ">


<?php echo form_open('Home/sizesubmit');?>


<div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Size</label>
    <?php echo form_input(['class'=>'form-control','placeholder'=>'Enter Size','name'=>'size','value'=>set_value('size')]); ?>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('size'); ?>
    </div>
  </div>



  <?php echo form_submit(['class'=>'btn btn-primary','type'=>'submit','value'=>'Submit']); ?>
  <?php echo form_reset(['class'=>'btn btn-success','type'=>'reset','value'=>'Reset']); ?>
  


</div>
  <?php include('footer.php') ?>