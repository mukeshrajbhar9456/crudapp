<?php include('header.php') ?>


<div class="container" style="margin-top: 50px;">


<?php echo form_open("home/updatsize/{$article->sid} "); ?>


<div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Size</label>
    <?php echo form_input(['class'=>'form-control','name'=>'size','value'=>set_value('size',$article->size)]); ?>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('size'); ?>
    </div>
  </div>



  <?php echo form_submit(['class'=>'btn btn-primary','type'=>'submit','value'=>'Submit']); ?>
 
  


</div>
  <?php include('footer.php') ?>