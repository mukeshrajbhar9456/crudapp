<?php

/**
 * 
 */
class Home_model extends CI_Model
{
	
	public function category()
	{
		$q= $this->db->select()
					 ->from('category')
					 ->get();
					 return $q->result();
	}


	public function addproduct($post)
	{
		return $this->db->insert('product',$post);

	}

	public function addcategory($post)
	{
		return $this->db->insert('category',$post);

	}

	public function deletecategory($catid)
	{
		 return $this->db->delete('category',['catid'=>$catid]);
	}

	public function deleteproduct($pid)
	{
		 return $this->db->delete('product',['pid'=>$pid]);
	}

	public function findcategory($articleid)
	{

		$q=$this->db->select()
            	    ->where('catid',$articleid)
            	   ->get('category');
            return $q->row();
		
	}


	public function findproduct($articleid)
	{

		$q=$this->db->select()
            	    ->where('pid',$articleid)
            	   ->get('product');
            return $q->row();
		
	}


	

public function deletesize($id)
	{
		 return $this->db->delete('size',['sid'=>$id]);
	}

public function size()
	{
		$q= $this->db->select()
					 ->from('size')
					 ->get();
					 return $q->result();
	}


public function addsize($post)
	{
		return $this->db->insert('size',$post);

	}

public function findsize($articleid)
	{

		$q=$this->db->select()
            	    ->where('sid',$articleid)
            	   ->get('size');
            return $q->row();
		
	}
		public function updatesize($articleid,array $article)
	{
		 return $this->db->where('sid',$articleid)
                   		 ->update('size',$article);

	}


	public function updatecat($articleid,array $article)
	{
		return $this->db->where('catid',$articleid)
						->update('category',$article);

	}


	public function updateproduct($articleid,array $article)
	{
		return $this->db->where('pid',$articleid)
						->update('product',$article);

	}


public function index()
	{
		$q= $this->db->select()
					 ->from('product')
					 ->get();
					 return $q->result();
	}



}





?>