<?php 

/**
 * 
 */
class Home extends CI_Controller
{
	
	public function index()
	{
		$this->load->model('home_model');
		$product= $this->home_model->index();
		$this->load->view('home',['product'=>$product]);
	}

	public function addproduct()
	{
		$this->load->model('home_model');
		$cat= $this->home_model->category();
		$siz= $this->home_model->size();

		
		$this->load->view('addproduct',['cat'=>$cat,'siz'=>$siz]);
	}


	public function prosubmit()
	{
		$this->form_validation->set_rules('pname','product','required');
		$this->form_validation->set_rules('catname','category','required');
		$this->form_validation->set_rules('pprice','price','required');
		$this->form_validation->set_rules('size','size','required');
		$this->form_validation->set_rules('pstock','stock','required');
		$this->form_validation->set_rules('pdescription','description','required');
		$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
    if($this->form_validation->run())
    {
      $post=$this->input->post();
      
      $this->load->model('home_model');
      if($this->home_model->addproduct($post))
      {
        $this->session->set_flashdata('success','New Product Added successfully');
        return redirect('home');
      }
      else{
        echo "login fail";
      }

      return redirect('home');

    }else{
      $this->addproduct();

    }


	}












	public function category()
	{
		$this->load->model('home_model');
		$category= $this->home_model->category();
		$this->load->view('category',['category'=>$category]);
	}


	public function addcategory()
	{
		$this->load->view('addcategory');
	}



	public function catsubmit()
	{
		$this->form_validation->set_rules('catname','category','required');

		$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');


    if($this->form_validation->run())
    {
      $post=$this->input->post();
      
      $this->load->model('home_model');
      if($this->home_model->addcategory($post))
      {
        $this->session->set_flashdata('success','New Category Added successfully');
        return redirect('home/category');
      }
      else{
        echo "login fail";
      }

      return redirect('home/category');

    }else{
      $this->addcategory();

    }
}



public function deletecategory()
{
	$catid=$this->input->post('id');
  
    $this->load->model('home_model');
      if($this->home_model->deletecategory($catid))
      {
          $this->session->set_flashdata('msg','Delete Successfully');
          $this->session->set_flashdata('msg_class','alert-success');
      }
      else
      {
         $this->session->set_flashdata('msg','Please try again..not delete');
         $this->session->set_flashdata('msg_class','alert-danger');
      }
      return redirect('home/category');
}


public function deleteproduct()
{
	$pid=$this->input->post('id');
  
    $this->load->model('home_model');
      if($this->home_model->deleteproduct($pid))
      {
          $this->session->set_flashdata('msg','Delete Successfully');
          $this->session->set_flashdata('msg_class','alert-success');
      }
      else
      {
         $this->session->set_flashdata('msg','Please try again..not delete');
         $this->session->set_flashdata('msg_class','alert-danger');
      }
      return redirect('home');
}


public function editcategory($id)
{
	$this->load->model('home_model');
 	$article=$this->home_model->findcategory($id);

	$this->load->view('editcategory',['article'=>$article]);
}


public function editproduct($id)
{
	$this->load->model('home_model');
 	$article=$this->home_model->findproduct($id);
 	$cat= $this->home_model->category();
	$siz= $this->home_model->size();

	$this->load->view('editproduct',['article'=>$article,'cat'=>$cat,'siz'=>$siz]);
}





public function deletesize()
{
	$id=$this->input->post('sid');
  
    $this->load->model('home_model');
      if($this->home_model->deletesize($id))
      {
          $this->session->set_flashdata('msg','Delete Successfully');
          $this->session->set_flashdata('msg_class','alert-success');
      }
      else
      {
         $this->session->set_flashdata('msg','Please try again..not delete');
         $this->session->set_flashdata('msg_class','alert-danger');
      }
      return redirect('home/size');
}


public function size()
	{
		$this->load->model('home_model');
		$size= $this->home_model->size();
		$this->load->view('size',['size'=>$size]);
	}

	public function addsize()
	{
		$this->load->view('addsize');
	}


	public function sizesubmit()
	{
		$this->form_validation->set_rules('size','Size','required');

		$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');


    if($this->form_validation->run())
    {
      $post=$this->input->post();
      
      $this->load->model('home_model');
      if($this->home_model->addsize($post))
      {
        $this->session->set_flashdata('success','New Size Added successfully');
        return redirect('home/size');
      }
      else{
        echo "login fail";
      }

      return redirect('home/size');

    }else{
      $this->addsize();

    }
	}

	public function editsize($id)
{
	$this->load->model('home_model');
 	$article=$this->home_model->findsize($id);

	$this->load->view('editsize',['article'=>$article]);
}



 public function updatsize($article_id)
 {
 	$this->form_validation->set_rules('size','Size','required');
	$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
	if($this->form_validation->run())
  {
      $post=$this->input->post(); 
      //$articleid=$post['article_id'];
      //unset($articleid);
      $this->load->model('home_model','editupdate');
      if($this->editupdate->updatesize($article_id,$post))
      {
         $this->session->set_flashdata('success','Size Update successfully');
          $this->session->set_flashdata('msg_class','alert-success');
      }
      else
      {
         $this->session->set_flashdata('msg','size not update Please try again!!');
         $this->session->set_flashdata('msg_class','alert-danger');
      }
      return redirect('home/size');
     }
  else
  {
    $this->editsize($article_id);
  }

 }


 public function updatecategory($article_id)
{
	$this->form_validation->set_rules('catname','category','required');

	$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');


	 if($this->form_validation->run())
    {
      $post=$this->input->post();
      
      $this->load->model('home_model');
      if($this->home_model->updatecat($article_id,$post))
      {
        $this->session->set_flashdata('success','Category Update successfully');
          $this->session->set_flashdata('msg_class','alert-success');
       
      }
      else{
        $this->session->set_flashdata('msg','Category not update Please try again!!');
         $this->session->set_flashdata('msg_class','alert-danger');
      }

       return redirect('home/category');

    }else{
      $this->addcategory();


    }
}






 public function updateproduct($article_id)
{
	$this->form_validation->set_rules('pname','product','required');
		$this->form_validation->set_rules('catname','category','required');
		$this->form_validation->set_rules('pprice','price','required');
		$this->form_validation->set_rules('size','size','required');
		$this->form_validation->set_rules('pstock','stock','required');
		$this->form_validation->set_rules('pdescription','description','required');
	$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');


	 if($this->form_validation->run())
    {
      $post=$this->input->post();
      
      $this->load->model('home_model');
      if($this->home_model->updateproduct($article_id,$post))
      {
        $this->session->set_flashdata('success','Product Update successfully');
          $this->session->set_flashdata('msg_class','alert-success');
       
      }
      else{
        $this->session->set_flashdata('msg','Category not update Please try again!!');
         $this->session->set_flashdata('msg_class','alert-danger');
      }

       return redirect('home');

    }else{
      $this->home();


    }
}





}




 ?>