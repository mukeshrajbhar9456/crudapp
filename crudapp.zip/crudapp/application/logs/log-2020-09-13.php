ERROR - 2020-09-13 18:00:09 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\crudapp\application\models\home_model.php 82
ERROR - 2020-09-13 18:05:40 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 54
ERROR - 2020-09-13 18:05:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\crudapp\application\views\home.php 54
ERROR - 2020-09-13 18:06:41 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 50
ERROR - 2020-09-13 18:06:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\crudapp\application\views\home.php 50
ERROR - 2020-09-13 18:06:46 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 50
ERROR - 2020-09-13 18:06:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\crudapp\application\views\home.php 50
ERROR - 2020-09-13 18:09:26 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 55
ERROR - 2020-09-13 18:09:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\crudapp\application\views\home.php 55
ERROR - 2020-09-13 18:10:02 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 55
ERROR - 2020-09-13 18:10:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\crudapp\application\views\home.php 55
ERROR - 2020-09-13 18:12:16 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 55
ERROR - 2020-09-13 18:12:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\crudapp\application\views\home.php 55
ERROR - 2020-09-13 18:12:17 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 55
ERROR - 2020-09-13 18:12:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\crudapp\application\views\home.php 55
ERROR - 2020-09-13 18:22:51 --> Severity: error --> Exception: Call to undefined method Home_model::index() C:\xampp\htdocs\crudapp\application\controllers\Home.php 12
ERROR - 2020-09-13 18:25:03 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 70
ERROR - 2020-09-13 18:25:03 --> Severity: Notice --> Trying to get property 'sid' of non-object C:\xampp\htdocs\crudapp\application\views\home.php 70
ERROR - 2020-09-13 18:25:03 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 74
ERROR - 2020-09-13 18:25:03 --> Severity: Notice --> Trying to get property 'sid' of non-object C:\xampp\htdocs\crudapp\application\views\home.php 74
ERROR - 2020-09-13 18:26:15 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 70
ERROR - 2020-09-13 18:26:15 --> Severity: Notice --> Trying to get property 'sid' of non-object C:\xampp\htdocs\crudapp\application\views\home.php 70
ERROR - 2020-09-13 18:26:15 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\crudapp\application\views\home.php 74
ERROR - 2020-09-13 18:26:15 --> Severity: Notice --> Trying to get property 'sid' of non-object C:\xampp\htdocs\crudapp\application\views\home.php 74




<div class="row">
  <div class="col-lg-6">
  <div class="form-group">
    <label for="Cource_name">Category</label>
   
    <select class="form-control" name="catname">
      <option value="">Select</option>
       <?php if (count($cat)): ?>
          <?php foreach ($cat as $cat): ?>

              <option value="<?php echo $cat->catid ?>"><?php echo $cat->catname ?></option>
              <option ></option>

            <?php endforeach; ?>
    <?php else:?>
    </select>
  </div>
</div>
  <div class="col-lg-6" style="margin-top: 35px;">
              <?php echo form_error('catname'); ?>
    </div> 
  </div>


  

  <select id="user" name="user" style="width: 230px; height: 40px;" >
<option value="" selected>--Select--</option>
<?php foreach ($result as $row) { ?>
<option value="<?php echo $row['id'] ; ?>" <?php echo set_select('user', $row['id'], False); ?> ><?php echo $row['employee_name'] ; ?> </option> 
<?php } ?>
</select>